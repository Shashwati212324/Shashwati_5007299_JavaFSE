package com.library;

import com.libb.service.BookService;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class LibraryManagementApplication {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("application context.xml");

        BookService bookService = (BookService) context.getBean("book Service");

        bookService.performService();
    }
}
